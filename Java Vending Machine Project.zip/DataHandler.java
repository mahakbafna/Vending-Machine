public interface DataHandler {
    public boolean write(String productsFW, String totalFW, String inputFW);
    public void displayUsers(java.io.PrintStream out);
    }